# 🛒 STO (Sistema Tienda Online)
Sistema de TIENDA en ONLINE desarrollada con tecnologías PHP, MVC, MySQL, JS, AJAX &amp; MDB 5

# ⚠️ ¡IMPORTANTE! ⚠️
<p>
Este proyecto actualmente se encuentra en desarrollo aún no está finalizado, suscríbete a mi canal para estar pendiente de las nuevas actualizaciones
</p>

# ▶️ INSTALACIÓN
<a href="https://youtu.be/NsvESL1lvpY" target="_blank">Ver video en YouTube</a>

# ⏱️ ACTUALIZACIONES DEL SISTEMA
✔️ <a href="https://youtu.be/qULhGDd6Ll4" target="_blank">Ver actualizaciones Junio 2021</a>

✔️ <a href="https://youtu.be/HsMLg56eKf0" target="_blank">Ver actualizaciones Abril 2021</a>

✔️ <a href="https://youtu.be/ZWYsTkeXZEA" target="_blank">Ver actualizaciones Marzo 2021</a>  

# 💙 APOYA ESTE PROYECTO 💙
<p>
Recuerda que puedes apoyar este proyecto suscribiéndote a mis canales de YouTube <a href="https://www.youtube.com/channel/UCRMJ0vxtnHh_UAq1Yx9BYWQ?sub_confirmation=1" target="_blank">CARLOS ALFARO</a> & <a href="https://www.youtube.com/channel/UCSKQJ3n2_CNjgB3sb2fvTdQ?sub_confirmation=1" target="_blank">DESIGNLOPERS</a>, tu apoyo es muy importante para seguir desarrollando este software y para traer nuevos proyectos.
</p>
